def printNum(num):
    print(num)
    if(num ==1):
        return
    printNum(num-1)




printNum(5)
print("hello World")

